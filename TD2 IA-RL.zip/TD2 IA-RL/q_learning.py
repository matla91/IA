import random
import gym
import numpy as np
from IPython.display import clear_output
import matplotlib.pyplot as plt
import time


def update_q_table(Q, s, a, r, sprime, alpha, gamma):
    """
    This function should update the Q function for a given pair of action-state
    following the q-learning algorithm, it takes as input the Q function, the pair action-state,
    the reward, the next state sprime, alpha the learning rate and gamma the discount factor.
    Return the same input Q but updated for the pair s and a.
    """
    max_Q_sprime = np.max(Q[sprime, :])
    Q[s, a] = Q[s, a] + alpha * (r + gamma * max_Q_sprime - Q[s, a])
    return Q


def epsilon_greedy(Q, s, epsilone):
    """
    This function implements the epsilon greedy algorithm.
    Takes as input the Q function for all states, a state s, and epsilon.
    It should return the action to take following the epsilon greedy algorithm.
    """
    if random.uniform(0, 1) < epsilone:
        # Choose a random action
        action = env.action_space.sample()
    else:
        # Choose the action with the highest Q value
        action = np.argmax(Q[s, :])
    return action


if __name__ == "__main__":
    env = gym.make("Taxi-v3")

    env.reset()

    Q = np.zeros([env.observation_space.n, env.action_space.n])

    alpha = 0.1  # learning rate

    gamma = 0.9  # discount factor

    epsilon = 0.2  # exploration rate

    n_epochs = 1000  # number of episodes
    max_itr_per_epoch = 100  # max iterations per episode
    rewards = []

    for e in range(n_epochs):
        r = 0

        S, _ = env.reset()

        for _ in range(max_itr_per_epoch):
            A = epsilon_greedy(Q=Q, s=S, epsilone=epsilon)

            Sprime, R, done, _, info = env.step(A)

            r += R

            Q = update_q_table(
                Q=Q, s=S, a=A, r=R, sprime=Sprime, alpha=alpha, gamma=gamma
            )

            S = Sprime  # Update state

            if done:
                break  # Episode finished

        print("Episode #", e, " : r = ", r)

        rewards.append(r)

    print("Average reward = ", np.mean(rewards))

    # Plot the rewards as a function of epochs
    plt.plot(rewards)
    plt.xlabel('Epoch')
    plt.ylabel('Total Reward')
    plt.title('Total Rewards over Epochs')
    plt.show()

    print("Training finished.\n")

    """
    Evaluate the q-learning algorithm
    """

    def evaluate_policy(Q, env, n_episodes=100):
        total_rewards = []
        for episode in range(n_episodes):
            S, _ = env.reset()
            total_reward = 0
            done = False
            while not done:
                A = np.argmax(Q[S, :])  # Choose best action
                Sprime, R, done, _, info = env.step(A)
                total_reward += R
                S = Sprime
            total_rewards.append(total_reward)
        avg_reward = np.mean(total_rewards)
        print(f"Average reward over {n_episodes} episodes: {avg_reward}")
        return total_rewards

    eval_rewards = evaluate_policy(Q, env, n_episodes=100)

    env.close()
